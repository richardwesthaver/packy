#![no_std]
#![feature(test)]

digest::bench!(blake2::Blake2s);
