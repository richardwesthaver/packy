//! Functions that bypass alsa-lib and talk directly to the kernel.

pub mod pcm;

mod ffi;
