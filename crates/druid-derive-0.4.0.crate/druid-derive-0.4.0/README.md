# druid-derive

This crate is implementations of derive macros for [druid][].

[druid]: https://github.com/linebender/druid
