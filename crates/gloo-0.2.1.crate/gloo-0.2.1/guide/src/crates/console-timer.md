{{#include ../../../crates/console-timer/README.md}}
