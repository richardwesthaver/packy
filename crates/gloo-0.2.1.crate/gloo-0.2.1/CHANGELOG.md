The format is based on [Keep a Changelog](http://keepachangelog.com/en/1.0.0/).

# [2019-12-12] gloo 0.2.0

## gloo-timers 0.2.0

### Changed
- Now uses `futures` version `0.3`, which means `async`/`await` works!
