//! Parsers recognizing bytes streams

#[macro_use]
mod macros;
pub mod complete;
pub mod streaming;
