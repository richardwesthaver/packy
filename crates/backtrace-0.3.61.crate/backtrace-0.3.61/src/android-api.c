// Used from the build script to detect the value of the `__ANDROID_API__`
// builtin #define

APIVERSION __ANDROID_API__
