# ndk-glue

Interoperability library for a native Rust application with the Android framework.
Provides access to `NativeActivity`, `NativeWindow` and `InputQueue`.

This library exports the `main` attribute macro from `ndk-macro`, see the corresponding README for more details.
