# Yew Router Examples
- minimal - Demonstrates how to use this library without the use of the Router component.
- router_component - Shows off the preferred way for how to use this library.

- switch - Various examples for how to construct routes with the router.

## Running
Details on how to build and run these examples can be found in the readme under `servers/`.

Using the router in its expected use case (not fragment routing) requires that the server respond to requests for
resources at URLs that are routes within the router with the index.html of the application.
