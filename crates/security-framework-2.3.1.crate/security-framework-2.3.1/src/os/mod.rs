//! OS specific extensions.

#[cfg(target_os = "macos")]
pub mod macos;
