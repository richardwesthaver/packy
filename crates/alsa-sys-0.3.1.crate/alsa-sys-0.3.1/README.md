# alsa-sys

Rust raw FFI bindings for ALSA.

To avoid too long build times, the finished binding is committed into this repository.
If you need to regenerate it, run `regenerate_bindings.sh` (and have `bindgen` set up when you do so).
