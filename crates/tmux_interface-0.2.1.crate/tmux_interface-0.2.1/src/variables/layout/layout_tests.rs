#[test]
fn parse() {
    //use crate::Layouts;
    //use crate::LayoutType;
    //use crate::Layout;

    //let "bcde,178x64,0,0[177x32,0,0{88x32,0,0,1,44x32,89,0,4,43x32,134,0,5},177x31,0,33{88x31,0,33,2,88x31,89,33,3}]"
    //let l = Layouts::parse("8b65,177x64,0,0[177x46,0,0,1,177x17,0,47,4]").unwrap();
    //let l_orig = Layouts {
    //style: LayoutType::TopBottom,
    //checksum: "8b65".to_string(),
    //parent: Layout {
    //x: 177,
    //y: 64,
    //x_off: 0,
    //y_off: 0,
    //id: None
    //},
    //layouts: None
    //};
    //assert_eq!(l_orig, l);

    //let l = Layouts::parse("8b65,177x64,0,0,1").unwrap();
    //let l_orig = Layouts {
    //style: LayoutType::WindowPane,
    //checksum: "8b65".to_string(),
    //parent: Layout {
    //x: 177,
    //y: 64,
    //x_off: 0,
    //y_off: 0,
    //id: Some(1)
    //},
    //layouts: None
    //};
    //assert_eq!(l_orig, l);

    //let l = Layouts::parse("8b65,177x64,0,0{177x46,0,0,1,177x17,0,47,4}").unwrap();
    //let l_orig = Layouts {
    //style: LayoutType::LeftRight,
    //checksum: "8b65".to_string(),
    //parent: Layout {
    //x: 177,
    //y: 64,
    //x_off: 0,
    //y_off: 0,
    //id: None
    //},
    //layouts: None
    //};
    //assert_eq!(l_orig, l);
}

//#[test]
//fn asdf() {
//use crate::Layouts;
//use crate::LayoutType;
//use crate::Layout;
//use crate::LayoutParseState;

//let layout_str = "8b65,177x64,0,0{177x46,0,0,1,177x17,0,47,4}";
//let l = Layouts::new();
//parse2(&self, layouts_str).unwrap();
//}
