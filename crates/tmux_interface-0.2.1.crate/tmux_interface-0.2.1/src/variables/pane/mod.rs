pub mod pane;
pub mod pane_tabs;
pub mod panes;

pub mod pane_tests;
//pub mod pane_tabs_tests;
pub mod panes_tests;
