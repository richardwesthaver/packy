# Procedural macros for the `stdweb` crate

These aren't the droids you are looking for; please go to [stdweb] instead.

[stdweb]: https://github.com/koute/stdweb
