# gio [![Build Status](https://travis-ci.org/gtk-rs/gio.png?branch=master)](https://travis-ci.org/gtk-rs/gio) [![Build status](https://ci.appveyor.com/api/projects/status/4773nkca4q8ayn4x/branch/master?svg=true)](https://ci.appveyor.com/project/GuillaumeGomez/gio) [![Gitter](https://badges.gitter.im/Join%20Chat.svg)](https://gitter.im/gtk-rs/gtk)

GIO bindings for Rust.

- [Gtk-rs project site](http://gtk-rs.org/)

- [Online documentation](http://gtk-rs.org/docs/)

- [Readme](https://github.com/gtk-rs/gtk/blob/master/README.md) in our
  [main repo](https://github.com/gtk-rs/gtk)

## License

MIT
