# xrandr

This crate aims to provide safe bindings to libxrandr. It currently supports 
reading most monitor properties.
