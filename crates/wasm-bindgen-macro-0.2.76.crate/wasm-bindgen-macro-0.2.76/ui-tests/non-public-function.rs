use wasm_bindgen::prelude::*;

#[wasm_bindgen]
fn foo() {}

fn main() {}
