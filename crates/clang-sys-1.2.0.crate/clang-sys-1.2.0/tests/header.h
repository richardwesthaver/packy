#ifndef HEADER_H_
#define HEADER_H_

int add(int a, int b);

#endif
