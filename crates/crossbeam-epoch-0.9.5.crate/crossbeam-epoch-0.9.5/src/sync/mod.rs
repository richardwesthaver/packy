//! Synchronization primitives.

pub(crate) mod list;
pub(crate) mod queue;
