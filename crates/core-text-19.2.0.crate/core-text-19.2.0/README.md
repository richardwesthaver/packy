# core-text-rs

[![Build Status](https://travis-ci.com/servo/core-text-rs.svg?branch=master)](https://travis-ci.com/servo/core-text-rs)
