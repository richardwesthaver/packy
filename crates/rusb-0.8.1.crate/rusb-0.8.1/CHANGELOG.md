# Changes


## 0.8.1
* Add getters for bRefresh and bSynchAddress [#61]
* Implement Display for Version. [#59]
* Add Device/DeviceHandle::context getter methods [#57]

[#61]: https://github.com/a1ien/rusb/pull/61
[#59]: https://github.com/a1ien/rusb/pull/59
[#57]: https://github.com/a1ien/rusb/pull/57
