# Version 0.2.3

- Fix bug in release (yanking 0.2.2)

# Version 0.2.2

- Fix unsoundness issues by adopting `MaybeUninit`. (#458)

# Version 0.2.1

- Add `no_std` support.

# Version 0.2.0

- Bump the minimum required version to 1.28.
- Bump `crossbeam-utils` to `0.7`.

# Version 0.1.2

- Update `crossbeam-utils` to `0.6.5`.

# Version 0.1.1

- Update `crossbeam-utils` to `0.6.4`.

# Version 0.1.0

- Initial version with `ArrayQueue` and `SegQueue`.
