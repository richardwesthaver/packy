# Unreleased

# 0.2.0 (2020-09-15)

- Added crate name override option
- **Breaking:** Changed macro attribute syntax

# 0.1.0 (2020-07-29)

- Initial release! 🎉
