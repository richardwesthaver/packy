# gdk [![Build Status](https://travis-ci.org/gtk-rs/gdk.png?branch=master)](https://travis-ci.org/gtk-rs/gdk) [![Build status](https://ci.appveyor.com/api/projects/status/x49sdkx68n0sa22g?svg=true)](https://ci.appveyor.com/project/GuillaumeGomez/gdk) [![Gitter](https://badges.gitter.im/Join%20Chat.svg)](https://gitter.im/gtk-rs/gtk)

Gdk bindings for Rust.

- [Gtk-rs project site](http://gtk-rs.org/)

- [Online documentation](http://gtk-rs.org/docs/)

- [Readme](https://github.com/gtk-rs/gtk/blob/master/README.md) in our
  [main repo](https://github.com/gtk-rs/gtk)

## License

MIT
