#define Float_0 0.
#define Float_1 1f
#define Float_p1 .1
#define Float_2 2.0
#define Float_1000 1e3
#define Float_2000 2e+3
#define Float_p001 1e-3
#define Float_80 10.0*(1<<3)
