The following context is extracted from
the `browser.xhtml` localization context
from mozilla-central rev 51efc4b931f7
from 2020-03-03.
