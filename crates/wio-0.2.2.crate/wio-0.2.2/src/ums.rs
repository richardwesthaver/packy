// Copyright © 2016, Peter Atashian
// Licensed under the MIT License <LICENSE.md>
use {k32, w};