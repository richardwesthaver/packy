# wio-rs #

A middle-level wrapper around various things in Windows API.
Designed to be a very thin layer around Windows API to provide a safe Rusty API but without hiding any functionality.
