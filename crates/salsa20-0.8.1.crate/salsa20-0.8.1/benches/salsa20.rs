#![feature(test)]

cipher::stream_cipher_sync_bench!(salsa20::Salsa20);
